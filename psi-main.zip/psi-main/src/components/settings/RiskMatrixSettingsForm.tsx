
import React from "react";
import RiskMatrixSettingsFormIntegrated from "@/components/risks/RiskMatrixSettingsFormIntegrated";

export default function RiskMatrixSettingsForm() {
  return <RiskMatrixSettingsFormIntegrated />;
}
