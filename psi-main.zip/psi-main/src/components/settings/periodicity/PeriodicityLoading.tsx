
import React from "react";

export function PeriodicityLoading() {
  return <div>Carregando configurações...</div>;
}
