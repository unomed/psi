
import React from "react";
import RiskAnalysisFormIntegrated from "@/components/risks/RiskAnalysisFormIntegrated";

export default function RiskAnalysisForm() {
  return <RiskAnalysisFormIntegrated />;
}
