
export interface Assessment {
  id: string | number;
  employee: string;
  sector: string;
  date: string;
  riskLevel: string;
}
